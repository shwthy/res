// Builds two separate datasets from the installed packages:
//   datasets/icons.json  (Phosphor topic icons)
//   datasets/logos.json  (Lobe Icons AI/tech brand logos)
// Run: node build_datasets.mjs
import fs from "node:fs";
import path from "node:path";

const OUT = "datasets";
fs.mkdirSync(OUT, { recursive: true });

// package.json is not in these packages' "exports", so resolve straight from node_modules
const phosphorDir = path.resolve("node_modules/@phosphor-icons/core");
const lobeDir = path.resolve("node_modules/@lobehub/icons-static-svg");
const phosphorVersion = JSON.parse(fs.readFileSync(path.join(phosphorDir, "package.json"), "utf8")).version;
const lobeVersion = JSON.parse(fs.readFileSync(path.join(lobeDir, "package.json"), "utf8")).version;

// ---------------------------------------------------------------- ICONS
const { icons: phosphor } = await import("@phosphor-icons/core");
const WEIGHTS = ["thin", "light", "regular", "bold", "fill", "duotone"];
const phosphorFile = (name, w) =>
  w === "regular" ? `assets/regular/${name}.svg` : `assets/${w}/${name}-${w}.svg`;

const icons = phosphor
  .map((i) => {
    const tags = i.tags.filter((t) => !t.startsWith("*")); // drop *new* / *updated*
    const weights = {};
    for (const w of WEIGHTS) {
      const f = phosphorFile(i.name, w);
      if (fs.existsSync(path.join(phosphorDir, f))) weights[w] = f;
    }
    const words = i.name.replace(/-/g, " ");
    return {
      id: i.name,
      package: "@phosphor-icons/core",
      name: i.name,
      pascal_name: i.pascal_name,
      categories: i.categories,
      figma_category: i.figma_category,
      tags,
      // brand glyphs (github-logo, x-logo...) are not topic icons; search should skip them
      is_brand_logo: i.categories.includes("brands"),
      files: weights,
      // text to embed later
      embed_text: `${words}. ${tags.join(", ")}. category: ${i.categories.join(", ")}`,
    };
  })
  .sort((a, b) => a.id.localeCompare(b.id));

// ---------------------------------------------------------------- LOGOS
// Curated seed aliases (lowercase). Headlines use product names more than company names.
const ALIASES = {
  openai: ["open ai", "chatgpt", "gpt", "gpt-4", "gpt-5", "gpt-4o", "o1", "o3", "sam altman"],
  sora: ["sora 2"],
  dalle: ["dall-e", "dall-e 3"],
  codex: ["openai codex"],
  anthropic: ["anthropic ai", "dario amodei"],
  claude: ["claude ai", "claude opus", "claude sonnet", "claude haiku", "claude 4"],
  claudecode: ["claude code"],
  deepseek: ["deepseek r1", "deepseek-r1", "deepseek v3", "deepseek-v3"],
  google: ["alphabet", "google ai", "google search", "sundar pichai"],
  gemini: ["google gemini", "gemini 2", "gemini 3", "gemini pro", "gemini ultra"],
  gemma: ["google gemma"],
  deepmind: ["google deepmind", "alphafold", "demis hassabis"],
  googlecloud: ["google cloud", "gcp"],
  meta: ["facebook", "instagram", "whatsapp", "mark zuckerberg", "meta platforms"],
  metaai: ["meta ai", "llama", "llama 3", "llama 4"],
  nvidia: ["nvda", "jensen huang", "blackwell", "h100", "h200", "cuda"],
  mistral: ["mistral ai", "le chat", "mixtral"],
  xai: ["x.ai", "elon musk ai"],
  grok: ["grok 3", "grok 4", "grok ai"],
  microsoft: ["msft", "satya nadella", "windows", "microsoft ai"],
  copilot: ["microsoft copilot"],
  githubcopilot: ["github copilot"],
  github: ["git hub"],
  azure: ["microsoft azure"],
  apple: ["apple intelligence", "iphone", "tim cook", "siri"],
  aws: ["amazon", "amazon web services", "andy jassy"],
  bedrock: ["amazon bedrock", "aws bedrock"],
  huggingface: ["hugging face", "hf"],
  perplexity: ["perplexity ai"],
  qwen: ["alibaba qwen", "qwen 3", "tongyi"],
  alibaba: ["alibaba group", "baba"],
  moonshot: ["moonshot ai"],
  kimi: ["kimi k2", "kimi ai"],
  baidu: ["ernie", "ernie bot"],
  wenxin: ["wenxin yiyan"],
  bytedance: ["tiktok", "douyin", "byte dance"],
  doubao: ["doubao ai"],
  tencent: ["wechat", "tencent holdings"],
  hunyuan: ["tencent hunyuan"],
  huawei: ["huawei technologies"],
  zhipu: ["zhipu ai", "glm"],
  minimax: ["minimax ai"],
  stepfun: ["step fun"],
  cohere: ["cohere ai", "command r"],
  stability: ["stability ai", "stable diffusion"],
  midjourney: ["mid journey"],
  runway: ["runway ml", "runwayml"],
  luma: ["luma ai", "dream machine"],
  kling: ["kling ai", "kuaishou"],
  flux: ["flux.1"],
  bfl: ["black forest labs"],
  elevenlabs: ["eleven labs"],
  suno: ["suno ai"],
  ollama: ["ollama ai"],
  groq: ["groq inc", "groq cloud"],
  cerebras: ["cerebras systems"],
  together: ["together ai"],
  openrouter: ["open router"],
  cursor: ["cursor ai", "anysphere"],
  windsurf: ["codeium"],
  replit: ["replit ai"],
  lovable: ["lovable dev"],
  manus: ["manus ai"],
  vercel: ["vercel ai"],
  v0: ["v0.dev", "vercel v0"],
  cloudflare: ["cloudflare inc"],
  snowflake: ["snowflake inc"],
  notion: ["notion ai"],
  figma: ["figma ai"],
  ibm: ["ibm watson", "watsonx", "international business machines"],
  replicate: ["replicate ai"],
  langchain: ["lang chain"],
  llamaindex: ["llama index"],
  sakana: ["sakana ai"],
  nousresearch: ["nous research", "hermes"],
  ai21: ["ai21 labs", "jamba"],
  inflection: ["inflection ai", "pi ai"],
  poolside: ["poolside ai"],
  devin: ["cognition ai", "cognition labs"],
  notebooklm: ["notebook lm"],
  yandex: ["yandexgpt"],
};

// Some Lobe <title> tags don't match the company (microsoft.svg is titled "Azure", xai.svg "Grok")
const NAME_OVERRIDES = { microsoft: "Microsoft", xai: "xAI" };

const SUFFIXES = ["brand-color", "text-color", "text-cn", "brand", "color", "text", "avatar"];
const files = fs.readdirSync(path.join(lobeDir, "icons")).filter((f) => f.endsWith(".svg"));

const bySlug = new Map();
for (const f of files) {
  const stem = f.replace(/\.svg$/, "");
  let variant = "mono";
  let slug = stem;
  for (const s of SUFFIXES) {
    if (stem.endsWith(`-${s}`)) {
      variant = s;
      slug = stem.slice(0, -(s.length + 1));
      break;
    }
  }
  if (!bySlug.has(slug)) bySlug.set(slug, { slug, variants: {} });
  bySlug.get(slug).variants[variant] = `icons/${f}`;
}

const titleOf = (file) => {
  const svg = fs.readFileSync(path.join(lobeDir, file), "utf8");
  const m = svg.match(/<title>([^<]+)<\/title>/);
  return m ? m[1].trim() : null;
};

const logos = [...bySlug.values()]
  .map(({ slug, variants }) => {
    const anyFile = variants.mono || variants.color || Object.values(variants)[0];
    const name = NAME_OVERRIDES[slug] || titleOf(anyFile) || slug;
    const aliases = [
      ...new Set([name.toLowerCase(), slug, ...(ALIASES[slug] || [])].map((a) => a.toLowerCase())),
    ];
    return {
      id: slug,
      package: "@lobehub/icons-static-svg",
      slug,
      name,
      aliases,
      has_color: Boolean(variants.color),
      variants, // mono | color | text | brand | brand-color | text-cn
      embed_text: `${name}. also known as: ${aliases.filter((a) => a !== name.toLowerCase()).join(", ") || name}`,
    };
  })
  .sort((a, b) => a.id.localeCompare(b.id));

// aliases that point at more than one logo (ambiguous) - useful to review
const aliasMap = new Map();
for (const l of logos) for (const a of l.aliases) aliasMap.set(a, [...(aliasMap.get(a) || []), l.id]);
const ambiguous = Object.fromEntries([...aliasMap].filter(([, ids]) => ids.length > 1));

const seedMissing = Object.keys(ALIASES).filter((s) => !bySlug.has(s));

fs.writeFileSync(path.join(OUT, "icons.json"), JSON.stringify(icons, null, 1));
fs.writeFileSync(path.join(OUT, "logos.json"), JSON.stringify(logos, null, 1));
fs.writeFileSync(
  path.join(OUT, "manifest.json"),
  JSON.stringify(
    {
      generated_by: "build_datasets.mjs",
      icons: {
        file: "icons.json",
        source: `@phosphor-icons/core@${phosphorVersion}`,
        license: "MIT",
        count: icons.length,
        topic_icons: icons.filter((i) => !i.is_brand_logo).length,
        brand_glyphs_flagged: icons.filter((i) => i.is_brand_logo).length,
        files_root: "node_modules/@phosphor-icons/core/",
        schema: "id, name, categories, tags, is_brand_logo, files{weight:path}, embed_text",
      },
      logos: {
        file: "logos.json",
        source: `@lobehub/icons-static-svg@${lobeVersion}`,
        license: "MIT (packaging); logos remain trademarks of their owners",
        count: logos.length,
        with_color_variant: logos.filter((l) => l.has_color).length,
        files_root: "node_modules/@lobehub/icons-static-svg/",
        schema: "id, slug, name, aliases[], has_color, variants{variant:path}, embed_text",
      },
      review: {
        ambiguous_aliases: ambiguous,
        seed_alias_slugs_not_in_lobe: seedMissing,
      },
    },
    null,
    1
  )
);

console.log({ icons: icons.length, logos: logos.length, ambiguous: Object.keys(ambiguous).length, seedMissing });
